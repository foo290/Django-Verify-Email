from django.apps import AppConfig


class VerifyEmailConfig(AppConfig):
    name = 'verify_email'
