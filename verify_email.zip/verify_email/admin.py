from django.contrib import admin
from .models import LinkCounter

admin.site.register(LinkCounter)
